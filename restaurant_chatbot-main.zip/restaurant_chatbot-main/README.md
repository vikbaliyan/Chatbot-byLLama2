# Restaurant_chatbot
A LLaMa based chatbot on yelp dataset for restaurant recommendation

# We have tried the following methods 
- Train a SFT model
- Use the orginal LLAMA v2 and index the documents to retrieve the answers
- Use the Orginal LLAMA v2 , index the documents and use context history in the chat

  
